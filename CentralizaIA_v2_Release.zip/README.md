# 🚀 CentralizaIA - Local AI Orchestrator & Dashboard

CentralizaIA é um dashboard premium para gestão de modelos de Inteligência Artificial local. Ele permite centralizar, organizar e lançar modelos (Ollama, ComfyUI, Llama.cpp, LM Studio) de forma inteligente, economizando espaço em disco através de Hardlinks.

---

## ⚡ Instalação & Uso (Single-Command)

O CentralizaIA agora roda de forma unificada em uma única porta para facilitar o uso.

### 1. Configuração e Início Automático
Abra o terminal na pasta do projeto e execute:
```bash
setup.bat
```
*Este comando instalará as dependências, compilará a interface e abrirá o dashboard no seu navegador automaticamente.*

### 2. Uso Diário
Após o primeiro setup, você pode iniciar a app apenas clicando em:
```bash
start_app.bat
```
- **Dashboard**: [http://localhost:4000](http://localhost:4000)

---

## ✨ Funcionalidades Principais

### 📂 Centralização Inteligente (Link Engine)
- **Zero Disk Waste**: Use Hardlinks para centralizar modelos sem ocupar espaço extra.
- **Gestão em Massa**: Selecione múltiplos modelos standalone e vincule-os ao repositório mestre.
- **Seletor Nativo**: Use o ícone de pasta nas configurações para escolher diretórios com o seletor nativo do Windows (sempre à frente do navegador).

### 🚀 Launch Engine (Orquestrador)
- **Lançamento Adaptativo**: O sistema detecta o motor ideal para cada modelo (Ollama vs Llama.cpp).
- **One-Click Server**: Inicie servidores diretamente pela interface em terminais dedicados.

### 🖥️ Hardware Lab & Telemetry
- **Monitoramento Real**: Detecção de VRAM via `nvidia-smi` e WMI.
- **Compatibility Check**: O sistema analisa sua memória e indica quais modelos rodam perfeitamente.

---

## 🛠️ Estrutura Técnica
- **Unificado**: O frontend é compilado (`npm run build`) e servido diretamente pelo Node.js na porta 4000.
- **Cross-Platform Picker**: Seleção de pastas compatível com Windows, Mac e Linux.

---
**Centralize sua inteligência. Otimize seu espaço.**
